data remove storage block_property_accessor: id
data remove storage block_property_accessor: properties
data remove storage block_property_accessor: traits
execute if block ~ ~ ~ #block_property_accessor:0 run function block_property_accessor:0/
execute if block ~ ~ ~ #block_property_accessor:1 run function block_property_accessor:1/
