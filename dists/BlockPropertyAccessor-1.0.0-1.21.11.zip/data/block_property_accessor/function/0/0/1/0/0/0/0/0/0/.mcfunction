execute if block ~ ~ ~ minecraft:cyan_concrete_powder run function block_property_accessor:0/0/1/0/0/0/0/0/0/cyan_concrete_powder
execute if block ~ ~ ~ minecraft:conduit run function block_property_accessor:0/0/1/0/0/0/0/0/0/conduit
