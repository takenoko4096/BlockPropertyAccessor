data modify storage block_property_accessor: id set value "minecraft:brain_coral_wall_fan"
execute if block ~ ~ ~ minecraft:brain_coral_wall_fan[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:brain_coral_wall_fan[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:brain_coral_wall_fan[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:brain_coral_wall_fan[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:brain_coral_wall_fan[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:brain_coral_wall_fan[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/1/0/0/0/0/1/1/1/brain_coral_wall_fan_traits
