execute if block ~ ~ ~ minecraft:brain_coral_wall_fan run function block_property_accessor:0/0/1/0/0/0/0/1/1/1/brain_coral_wall_fan
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor run function block_property_accessor:0/0/1/0/0/0/0/1/1/1/waxed_exposed_copper_trapdoor
