data modify storage block_property_accessor: id set value "minecraft:acacia_log"
execute if block ~ ~ ~ minecraft:acacia_log[axis=x] run data modify storage block_property_accessor: properties.axis set value x
execute if block ~ ~ ~ minecraft:acacia_log[axis=y] run data modify storage block_property_accessor: properties.axis set value y
execute if block ~ ~ ~ minecraft:acacia_log[axis=z] run data modify storage block_property_accessor: properties.axis set value z
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/1/0/0/0/0/1/0/acacia_log_traits
