execute if block ~ ~ ~ minecraft:sticky_piston run function block_property_accessor:0/0/1/0/0/0/1/0/0/sticky_piston
execute if block ~ ~ ~ minecraft:gray_concrete run function block_property_accessor:0/0/1/0/0/0/1/0/0/gray_concrete
