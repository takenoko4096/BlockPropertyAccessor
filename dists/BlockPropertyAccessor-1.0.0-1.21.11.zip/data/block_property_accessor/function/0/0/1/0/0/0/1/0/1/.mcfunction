execute if block ~ ~ ~ minecraft:dead_tube_coral_wall_fan run function block_property_accessor:0/0/1/0/0/0/1/0/1/dead_tube_coral_wall_fan
execute if block ~ ~ ~ minecraft:blue_glazed_terracotta run function block_property_accessor:0/0/1/0/0/0/1/0/1/blue_glazed_terracotta
