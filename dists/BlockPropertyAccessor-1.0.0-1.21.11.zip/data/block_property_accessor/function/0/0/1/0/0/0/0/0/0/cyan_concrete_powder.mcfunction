data modify storage block_property_accessor: id set value "minecraft:cyan_concrete_powder"
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/1/0/0/0/0/0/0/cyan_concrete_powder_traits
