data modify storage block_property_accessor: id set value "minecraft:sticky_piston"
execute if block ~ ~ ~ minecraft:sticky_piston[extended=true] run data modify storage block_property_accessor: properties.extended set value true
execute if block ~ ~ ~ minecraft:sticky_piston[extended=false] run data modify storage block_property_accessor: properties.extended set value false
execute if block ~ ~ ~ minecraft:sticky_piston[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:sticky_piston[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:sticky_piston[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:sticky_piston[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:sticky_piston[facing=up] run data modify storage block_property_accessor: properties.facing set value up
execute if block ~ ~ ~ minecraft:sticky_piston[facing=down] run data modify storage block_property_accessor: properties.facing set value down
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/1/0/0/0/1/0/0/sticky_piston_traits
