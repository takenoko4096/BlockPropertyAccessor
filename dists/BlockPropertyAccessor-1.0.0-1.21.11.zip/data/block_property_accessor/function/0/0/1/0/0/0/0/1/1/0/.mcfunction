execute if block ~ ~ ~ minecraft:light_blue_concrete run function block_property_accessor:0/0/1/0/0/0/0/1/1/0/light_blue_concrete
