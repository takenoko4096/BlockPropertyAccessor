data modify storage block_property_accessor: id set value "minecraft:potted_spruce_sapling"
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/1/0/0/0/0/0/1/potted_spruce_sapling_traits
