execute if block ~ ~ ~ minecraft:jigsaw run function block_property_accessor:0/0/1/0/0/0/1/1/0/jigsaw
execute if block ~ ~ ~ minecraft:stripped_spruce_log run function block_property_accessor:0/0/1/0/0/0/1/1/0/stripped_spruce_log
