execute if block ~ ~ ~ minecraft:sand run function block_property_accessor:0/0/1/0/0/0/0/0/1/sand
execute if block ~ ~ ~ minecraft:potted_spruce_sapling run function block_property_accessor:0/0/1/0/0/0/0/0/1/potted_spruce_sapling
