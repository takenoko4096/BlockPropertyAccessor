execute if block ~ ~ ~ minecraft:polished_granite_slab run function block_property_accessor:0/0/1/0/0/0/0/1/0/polished_granite_slab
execute if block ~ ~ ~ minecraft:acacia_log run function block_property_accessor:0/0/1/0/0/0/0/1/0/acacia_log
