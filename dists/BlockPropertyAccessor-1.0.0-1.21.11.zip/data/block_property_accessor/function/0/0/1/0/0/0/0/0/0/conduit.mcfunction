data modify storage block_property_accessor: id set value "minecraft:conduit"
execute if block ~ ~ ~ minecraft:conduit[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:conduit[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/1/0/0/0/0/0/0/conduit_traits
