data modify storage block_property_accessor: id set value "minecraft:waxed_exposed_copper_trapdoor"
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[half=top] run data modify storage block_property_accessor: properties.half set value top
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[half=bottom] run data modify storage block_property_accessor: properties.half set value bottom
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[open=true] run data modify storage block_property_accessor: properties.open set value true
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[open=false] run data modify storage block_property_accessor: properties.open set value false
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[powered=true] run data modify storage block_property_accessor: properties.powered set value true
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[powered=false] run data modify storage block_property_accessor: properties.powered set value false
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_trapdoor[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/1/0/0/0/0/1/1/1/waxed_exposed_copper_trapdoor_traits
