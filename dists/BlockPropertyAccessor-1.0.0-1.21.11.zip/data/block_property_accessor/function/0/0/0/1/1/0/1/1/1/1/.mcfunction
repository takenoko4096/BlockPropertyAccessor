execute if block ~ ~ ~ minecraft:smooth_red_sandstone_slab run function block_property_accessor:0/0/0/1/1/0/1/1/1/1/smooth_red_sandstone_slab
execute if block ~ ~ ~ minecraft:dark_oak_shelf run function block_property_accessor:0/0/0/1/1/0/1/1/1/1/dark_oak_shelf
