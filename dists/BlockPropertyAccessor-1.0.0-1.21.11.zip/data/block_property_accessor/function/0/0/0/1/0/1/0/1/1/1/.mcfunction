execute if block ~ ~ ~ minecraft:magenta_bed run function block_property_accessor:0/0/0/1/0/1/0/1/1/1/magenta_bed
execute if block ~ ~ ~ minecraft:nether_sprouts run function block_property_accessor:0/0/0/1/0/1/0/1/1/1/nether_sprouts
