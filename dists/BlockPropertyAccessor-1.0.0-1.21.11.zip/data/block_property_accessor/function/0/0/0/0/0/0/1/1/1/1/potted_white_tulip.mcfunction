data modify storage block_property_accessor: id set value "minecraft:potted_white_tulip"
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/0/1/1/1/1/potted_white_tulip_traits
