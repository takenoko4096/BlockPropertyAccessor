execute if block ~ ~ ~ minecraft:potted_warped_fungus run function block_property_accessor:0/0/0/1/0/0/0/0/0/potted_warped_fungus
execute if block ~ ~ ~ minecraft:birch_sapling run function block_property_accessor:0/0/0/1/0/0/0/0/0/birch_sapling
