execute if block ~ ~ ~ minecraft:black_shulker_box run function block_property_accessor:0/0/0/1/1/0/0/1/1/1/black_shulker_box
execute if block ~ ~ ~ minecraft:oxidized_copper_grate run function block_property_accessor:0/0/0/1/1/0/0/1/1/1/oxidized_copper_grate
