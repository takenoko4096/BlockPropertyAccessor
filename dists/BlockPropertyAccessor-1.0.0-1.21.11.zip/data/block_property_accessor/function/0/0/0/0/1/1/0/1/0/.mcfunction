execute if block ~ ~ ~ minecraft:spruce_fence_gate run function block_property_accessor:0/0/0/0/1/1/0/1/0/spruce_fence_gate
execute if block ~ ~ ~ minecraft:spruce_sapling run function block_property_accessor:0/0/0/0/1/1/0/1/0/spruce_sapling
