execute if block ~ ~ ~ minecraft:prismarine_stairs run function block_property_accessor:0/0/0/1/1/1/1/1/1/0/prismarine_stairs
