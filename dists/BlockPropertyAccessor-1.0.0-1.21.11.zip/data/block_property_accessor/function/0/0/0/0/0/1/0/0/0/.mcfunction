execute if block ~ ~ ~ minecraft:nether_gold_ore run function block_property_accessor:0/0/0/0/0/1/0/0/0/nether_gold_ore
execute if block ~ ~ ~ minecraft:bone_block run function block_property_accessor:0/0/0/0/0/1/0/0/0/bone_block
