execute if block ~ ~ ~ minecraft:candle_cake run function block_property_accessor:0/0/0/1/1/1/0/0/0/candle_cake
execute if block ~ ~ ~ minecraft:stripped_pale_oak_wood run function block_property_accessor:0/0/0/1/1/1/0/0/0/stripped_pale_oak_wood
