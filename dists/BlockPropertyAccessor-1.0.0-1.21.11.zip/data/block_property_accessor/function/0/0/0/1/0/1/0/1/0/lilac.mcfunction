data modify storage block_property_accessor: id set value "minecraft:lilac"
execute if block ~ ~ ~ minecraft:lilac[half=upper] run data modify storage block_property_accessor: properties.half set value upper
execute if block ~ ~ ~ minecraft:lilac[half=lower] run data modify storage block_property_accessor: properties.half set value lower
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/1/0/1/0/lilac_traits
