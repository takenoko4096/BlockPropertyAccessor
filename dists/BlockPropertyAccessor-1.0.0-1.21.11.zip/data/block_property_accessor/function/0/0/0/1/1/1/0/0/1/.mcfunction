execute if block ~ ~ ~ minecraft:end_gateway run function block_property_accessor:0/0/0/1/1/1/0/0/1/end_gateway
execute if block ~ ~ ~ minecraft:bamboo_pressure_plate run function block_property_accessor:0/0/0/1/1/1/0/0/1/bamboo_pressure_plate
