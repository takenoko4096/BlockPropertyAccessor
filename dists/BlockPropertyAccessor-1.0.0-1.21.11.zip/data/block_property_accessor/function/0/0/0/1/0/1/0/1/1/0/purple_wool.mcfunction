data modify storage block_property_accessor: id set value "minecraft:purple_wool"
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/1/0/1/1/0/purple_wool_traits
