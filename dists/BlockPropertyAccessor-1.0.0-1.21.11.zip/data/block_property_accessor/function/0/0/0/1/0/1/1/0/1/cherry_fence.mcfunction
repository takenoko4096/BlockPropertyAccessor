data modify storage block_property_accessor: id set value "minecraft:cherry_fence"
execute if block ~ ~ ~ minecraft:cherry_fence[east=true] run data modify storage block_property_accessor: properties.east set value true
execute if block ~ ~ ~ minecraft:cherry_fence[east=false] run data modify storage block_property_accessor: properties.east set value false
execute if block ~ ~ ~ minecraft:cherry_fence[north=true] run data modify storage block_property_accessor: properties.north set value true
execute if block ~ ~ ~ minecraft:cherry_fence[north=false] run data modify storage block_property_accessor: properties.north set value false
execute if block ~ ~ ~ minecraft:cherry_fence[south=true] run data modify storage block_property_accessor: properties.south set value true
execute if block ~ ~ ~ minecraft:cherry_fence[south=false] run data modify storage block_property_accessor: properties.south set value false
execute if block ~ ~ ~ minecraft:cherry_fence[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:cherry_fence[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if block ~ ~ ~ minecraft:cherry_fence[west=true] run data modify storage block_property_accessor: properties.west set value true
execute if block ~ ~ ~ minecraft:cherry_fence[west=false] run data modify storage block_property_accessor: properties.west set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/1/1/0/1/cherry_fence_traits
