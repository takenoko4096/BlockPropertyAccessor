execute if block ~ ~ ~ minecraft:waxed_weathered_copper_door run function block_property_accessor:0/0/0/0/0/1/1/0/0/waxed_weathered_copper_door
execute if block ~ ~ ~ minecraft:deepslate_gold_ore run function block_property_accessor:0/0/0/0/0/1/1/0/0/deepslate_gold_ore
