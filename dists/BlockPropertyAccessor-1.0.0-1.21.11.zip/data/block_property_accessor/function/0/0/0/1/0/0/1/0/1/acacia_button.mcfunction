data modify storage block_property_accessor: id set value "minecraft:acacia_button"
execute if block ~ ~ ~ minecraft:acacia_button[face=floor] run data modify storage block_property_accessor: properties.face set value floor
execute if block ~ ~ ~ minecraft:acacia_button[face=wall] run data modify storage block_property_accessor: properties.face set value wall
execute if block ~ ~ ~ minecraft:acacia_button[face=ceiling] run data modify storage block_property_accessor: properties.face set value ceiling
execute if block ~ ~ ~ minecraft:acacia_button[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:acacia_button[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:acacia_button[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:acacia_button[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:acacia_button[powered=true] run data modify storage block_property_accessor: properties.powered set value true
execute if block ~ ~ ~ minecraft:acacia_button[powered=false] run data modify storage block_property_accessor: properties.powered set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/0/1/0/1/acacia_button_traits
