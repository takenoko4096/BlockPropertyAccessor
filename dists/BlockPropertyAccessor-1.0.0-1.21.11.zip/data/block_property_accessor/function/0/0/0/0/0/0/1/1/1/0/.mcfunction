execute if block ~ ~ ~ minecraft:stonecutter run function block_property_accessor:0/0/0/0/0/0/1/1/1/0/stonecutter
