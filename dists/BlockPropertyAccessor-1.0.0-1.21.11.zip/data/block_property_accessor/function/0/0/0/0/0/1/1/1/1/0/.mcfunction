execute if block ~ ~ ~ minecraft:weathered_copper_bars run function block_property_accessor:0/0/0/0/0/1/1/1/1/0/weathered_copper_bars
