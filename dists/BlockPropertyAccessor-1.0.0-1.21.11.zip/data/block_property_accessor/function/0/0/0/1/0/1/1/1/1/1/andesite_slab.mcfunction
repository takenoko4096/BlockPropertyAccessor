data modify storage block_property_accessor: id set value "minecraft:andesite_slab"
execute if block ~ ~ ~ minecraft:andesite_slab[type=top] run data modify storage block_property_accessor: properties.type set value top
execute if block ~ ~ ~ minecraft:andesite_slab[type=bottom] run data modify storage block_property_accessor: properties.type set value bottom
execute if block ~ ~ ~ minecraft:andesite_slab[type=double] run data modify storage block_property_accessor: properties.type set value double
execute if block ~ ~ ~ minecraft:andesite_slab[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:andesite_slab[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/1/1/1/1/1/andesite_slab_traits
