data modify storage block_property_accessor: id set value "minecraft:mangrove_wood"
execute if block ~ ~ ~ minecraft:mangrove_wood[axis=x] run data modify storage block_property_accessor: properties.axis set value x
execute if block ~ ~ ~ minecraft:mangrove_wood[axis=y] run data modify storage block_property_accessor: properties.axis set value y
execute if block ~ ~ ~ minecraft:mangrove_wood[axis=z] run data modify storage block_property_accessor: properties.axis set value z
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/1/1/0/1/1/mangrove_wood_traits
