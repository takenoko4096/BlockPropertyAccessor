execute if block ~ ~ ~ minecraft:waxed_exposed_copper_lantern run function block_property_accessor:0/0/0/0/1/0/0/0/1/waxed_exposed_copper_lantern
execute if block ~ ~ ~ minecraft:chiseled_tuff run function block_property_accessor:0/0/0/0/1/0/0/0/1/chiseled_tuff
