execute if block ~ ~ ~ minecraft:andesite_slab run function block_property_accessor:0/0/0/1/0/1/1/1/1/1/andesite_slab
execute if block ~ ~ ~ minecraft:dark_prismarine_slab run function block_property_accessor:0/0/0/1/0/1/1/1/1/1/dark_prismarine_slab
