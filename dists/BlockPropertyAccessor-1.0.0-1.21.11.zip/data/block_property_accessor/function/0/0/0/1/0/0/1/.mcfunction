execute if block ~ ~ ~ #block_property_accessor:0/0/0/1/0/0/1/0 run function block_property_accessor:0/0/0/1/0/0/1/0/
execute if block ~ ~ ~ #block_property_accessor:0/0/0/1/0/0/1/1 run function block_property_accessor:0/0/0/1/0/0/1/1/
