data modify storage block_property_accessor: traits.blast_resistance set value 6.0f
data modify storage block_property_accessor: traits.hardness set value 1.5f
data modify storage block_property_accessor: traits.slipperiness set value 0.6f
data modify storage block_property_accessor: traits.is_flammable set value false
data modify storage block_property_accessor: traits.is_burnable set value false
data modify storage block_property_accessor: traits.is_occluding set value true
data modify storage block_property_accessor: traits.is_solid set value true
data modify storage block_property_accessor: traits.has_collision set value true
data modify storage block_property_accessor: traits.has_gravity set value false
data modify storage block_property_accessor: traits.is_air set value false
data modify storage block_property_accessor: traits.translation_key set value "block.minecraft.chiseled_tuff_bricks"
data modify storage block_property_accessor: traits.item_type set value "minecraft:chiseled_tuff_bricks"
data modify storage block_property_accessor: traits.light_emission set value "0"
data modify storage block_property_accessor: traits.map_color set value {red: "57", green: "41", blue: "35"}
data modify storage block_property_accessor: traits.sound_group set value {on_fall: "minecraft:block.tuff_bricks.fall", volume: 1.0f, on_place: "minecraft:block.tuff_bricks.place", on_hit: "minecraft:block.tuff_bricks.hit", on_break: "minecraft:block.tuff_bricks.break", on_step: "minecraft:block.tuff_bricks.step", pitch: 1.0f}
data modify storage block_property_accessor: traits.piston_move_reaction set value "move"
data modify storage block_property_accessor: traits.is_replaceable set value false
data modify storage block_property_accessor: traits.is_randomly_ticked set value false
data modify storage block_property_accessor: traits.requires_correct_tool_for_drops set value true
data modify storage block_property_accessor: traits.loot_table set value "minecraft:blocks/chiseled_tuff_bricks"
data modify storage block_property_accessor: traits.speed_factor set value 1.0f
data modify storage block_property_accessor: traits.jump_factor set value 1.0f
