execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chain run function block_property_accessor:0/0/0/1/1/1/0/1/1/1/waxed_oxidized_copper_chain
execute if block ~ ~ ~ minecraft:weathered_cut_copper_slab run function block_property_accessor:0/0/0/1/1/1/0/1/1/1/weathered_cut_copper_slab
