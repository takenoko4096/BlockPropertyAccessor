execute if block ~ ~ ~ minecraft:polished_blackstone_wall run function block_property_accessor:0/0/0/1/1/0/1/1/0/polished_blackstone_wall
execute if block ~ ~ ~ minecraft:cobblestone_stairs run function block_property_accessor:0/0/0/1/1/0/1/1/0/cobblestone_stairs
