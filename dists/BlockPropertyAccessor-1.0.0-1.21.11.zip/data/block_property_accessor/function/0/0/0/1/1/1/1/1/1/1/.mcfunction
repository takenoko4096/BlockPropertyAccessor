execute if block ~ ~ ~ minecraft:stripped_bamboo_block run function block_property_accessor:0/0/0/1/1/1/1/1/1/1/stripped_bamboo_block
execute if block ~ ~ ~ minecraft:bamboo_wall_hanging_sign run function block_property_accessor:0/0/0/1/1/1/1/1/1/1/bamboo_wall_hanging_sign
