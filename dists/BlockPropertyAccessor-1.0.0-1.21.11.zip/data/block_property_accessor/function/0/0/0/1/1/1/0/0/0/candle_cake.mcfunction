data modify storage block_property_accessor: id set value "minecraft:candle_cake"
execute if block ~ ~ ~ minecraft:candle_cake[lit=true] run data modify storage block_property_accessor: properties.lit set value true
execute if block ~ ~ ~ minecraft:candle_cake[lit=false] run data modify storage block_property_accessor: properties.lit set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/1/0/0/0/candle_cake_traits
