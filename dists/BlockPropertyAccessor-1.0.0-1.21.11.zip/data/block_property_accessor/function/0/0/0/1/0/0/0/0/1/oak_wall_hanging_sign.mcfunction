data modify storage block_property_accessor: id set value "minecraft:oak_wall_hanging_sign"
execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/0/0/0/1/oak_wall_hanging_sign_traits
