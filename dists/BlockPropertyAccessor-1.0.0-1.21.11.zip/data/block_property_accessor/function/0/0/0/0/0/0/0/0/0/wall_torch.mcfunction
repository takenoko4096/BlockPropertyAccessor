data modify storage block_property_accessor: id set value "minecraft:wall_torch"
execute if block ~ ~ ~ minecraft:wall_torch[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:wall_torch[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:wall_torch[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:wall_torch[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/0/0/0/0/wall_torch_traits
