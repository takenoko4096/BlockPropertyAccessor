data modify storage block_property_accessor: id set value "minecraft:waxed_exposed_copper_lantern"
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_lantern[hanging=true] run data modify storage block_property_accessor: properties.hanging set value true
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_lantern[hanging=false] run data modify storage block_property_accessor: properties.hanging set value false
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_lantern[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:waxed_exposed_copper_lantern[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/0/0/0/1/waxed_exposed_copper_lantern_traits
