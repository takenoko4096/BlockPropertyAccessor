execute if block ~ ~ ~ minecraft:pale_oak_shelf run function block_property_accessor:0/0/0/0/0/1/0/0/1/pale_oak_shelf
execute if block ~ ~ ~ minecraft:black_concrete run function block_property_accessor:0/0/0/0/0/1/0/0/1/black_concrete
