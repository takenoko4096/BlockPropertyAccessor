execute if block ~ ~ ~ minecraft:magenta_wool run function block_property_accessor:0/0/0/0/1/0/1/0/0/magenta_wool
execute if block ~ ~ ~ minecraft:lime_stained_glass_pane run function block_property_accessor:0/0/0/0/1/0/1/0/0/lime_stained_glass_pane
