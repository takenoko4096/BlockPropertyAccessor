execute if block ~ ~ ~ minecraft:mangrove_wood run function block_property_accessor:0/0/0/1/1/1/1/0/1/1/mangrove_wood
execute if block ~ ~ ~ minecraft:green_wall_banner run function block_property_accessor:0/0/0/1/1/1/1/0/1/1/green_wall_banner
