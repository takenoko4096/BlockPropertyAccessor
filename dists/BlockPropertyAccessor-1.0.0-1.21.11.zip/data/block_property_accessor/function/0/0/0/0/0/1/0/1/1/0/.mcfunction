execute if block ~ ~ ~ minecraft:birch_fence run function block_property_accessor:0/0/0/0/0/1/0/1/1/0/birch_fence
