execute if block ~ ~ ~ minecraft:flower_pot run function block_property_accessor:0/0/0/1/0/0/1/0/0/flower_pot
execute if block ~ ~ ~ minecraft:chiseled_nether_bricks run function block_property_accessor:0/0/0/1/0/0/1/0/0/chiseled_nether_bricks
