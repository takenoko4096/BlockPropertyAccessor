data modify storage block_property_accessor: id set value "minecraft:nether_gold_ore"
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/1/0/0/0/nether_gold_ore_traits
