execute if block ~ ~ ~ minecraft:brown_mushroom run function block_property_accessor:0/0/0/0/0/0/1/0/1/brown_mushroom
execute if block ~ ~ ~ minecraft:red_wool run function block_property_accessor:0/0/0/0/0/0/1/0/1/red_wool
