execute if block ~ ~ ~ minecraft:melon run function block_property_accessor:0/0/0/0/0/1/0/1/0/melon
execute if block ~ ~ ~ minecraft:bamboo_wall_sign run function block_property_accessor:0/0/0/0/0/1/0/1/0/bamboo_wall_sign
