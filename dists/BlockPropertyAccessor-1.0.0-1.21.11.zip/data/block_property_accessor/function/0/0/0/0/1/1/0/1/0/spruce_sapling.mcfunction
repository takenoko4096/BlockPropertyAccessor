data modify storage block_property_accessor: id set value "minecraft:spruce_sapling"
execute if block ~ ~ ~ minecraft:spruce_sapling[stage=0] run data modify storage block_property_accessor: properties.stage set value 0
execute if block ~ ~ ~ minecraft:spruce_sapling[stage=1] run data modify storage block_property_accessor: properties.stage set value 1
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/1/0/1/0/spruce_sapling_traits
