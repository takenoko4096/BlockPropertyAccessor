data modify storage block_property_accessor: id set value "minecraft:small_dripleaf"
execute if block ~ ~ ~ minecraft:small_dripleaf[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:small_dripleaf[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:small_dripleaf[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:small_dripleaf[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:small_dripleaf[half=upper] run data modify storage block_property_accessor: properties.half set value upper
execute if block ~ ~ ~ minecraft:small_dripleaf[half=lower] run data modify storage block_property_accessor: properties.half set value lower
execute if block ~ ~ ~ minecraft:small_dripleaf[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:small_dripleaf[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/1/0/1/0/small_dripleaf_traits
