data modify storage block_property_accessor: id set value "minecraft:gray_candle"
execute if block ~ ~ ~ minecraft:gray_candle[candles=1] run data modify storage block_property_accessor: properties.candles set value 1
execute if block ~ ~ ~ minecraft:gray_candle[candles=2] run data modify storage block_property_accessor: properties.candles set value 2
execute if block ~ ~ ~ minecraft:gray_candle[candles=3] run data modify storage block_property_accessor: properties.candles set value 3
execute if block ~ ~ ~ minecraft:gray_candle[candles=4] run data modify storage block_property_accessor: properties.candles set value 4
execute if block ~ ~ ~ minecraft:gray_candle[lit=true] run data modify storage block_property_accessor: properties.lit set value true
execute if block ~ ~ ~ minecraft:gray_candle[lit=false] run data modify storage block_property_accessor: properties.lit set value false
execute if block ~ ~ ~ minecraft:gray_candle[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:gray_candle[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/0/1/0/0/gray_candle_traits
