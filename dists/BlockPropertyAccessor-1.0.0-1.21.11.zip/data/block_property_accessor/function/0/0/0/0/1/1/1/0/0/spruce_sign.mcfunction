data modify storage block_property_accessor: id set value "minecraft:spruce_sign"
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=0] run data modify storage block_property_accessor: properties.rotation set value 0
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=1] run data modify storage block_property_accessor: properties.rotation set value 1
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=2] run data modify storage block_property_accessor: properties.rotation set value 2
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=3] run data modify storage block_property_accessor: properties.rotation set value 3
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=4] run data modify storage block_property_accessor: properties.rotation set value 4
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=5] run data modify storage block_property_accessor: properties.rotation set value 5
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=6] run data modify storage block_property_accessor: properties.rotation set value 6
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=7] run data modify storage block_property_accessor: properties.rotation set value 7
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=8] run data modify storage block_property_accessor: properties.rotation set value 8
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=9] run data modify storage block_property_accessor: properties.rotation set value 9
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=10] run data modify storage block_property_accessor: properties.rotation set value 10
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=11] run data modify storage block_property_accessor: properties.rotation set value 11
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=12] run data modify storage block_property_accessor: properties.rotation set value 12
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=13] run data modify storage block_property_accessor: properties.rotation set value 13
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=14] run data modify storage block_property_accessor: properties.rotation set value 14
execute if block ~ ~ ~ minecraft:spruce_sign[rotation=15] run data modify storage block_property_accessor: properties.rotation set value 15
execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:spruce_sign[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/1/1/0/0/spruce_sign_traits
