execute if block ~ ~ ~ minecraft:yellow_bed run function block_property_accessor:0/0/0/0/1/1/0/1/1/0/yellow_bed
