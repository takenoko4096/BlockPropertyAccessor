execute if block ~ ~ ~ minecraft:mossy_stone_brick_slab run function block_property_accessor:0/0/0/1/0/1/1/1/1/0/mossy_stone_brick_slab
