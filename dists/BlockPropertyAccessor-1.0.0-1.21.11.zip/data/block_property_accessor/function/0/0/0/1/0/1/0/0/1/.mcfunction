execute if block ~ ~ ~ minecraft:potted_flowering_azalea_bush run function block_property_accessor:0/0/0/1/0/1/0/0/1/potted_flowering_azalea_bush
execute if block ~ ~ ~ minecraft:brain_coral_fan run function block_property_accessor:0/0/0/1/0/1/0/0/1/brain_coral_fan
