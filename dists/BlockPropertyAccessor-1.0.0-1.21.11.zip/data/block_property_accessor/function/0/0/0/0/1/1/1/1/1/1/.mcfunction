execute if block ~ ~ ~ minecraft:tripwire run function block_property_accessor:0/0/0/0/1/1/1/1/1/1/tripwire
execute if block ~ ~ ~ minecraft:birch_wood run function block_property_accessor:0/0/0/0/1/1/1/1/1/1/birch_wood
