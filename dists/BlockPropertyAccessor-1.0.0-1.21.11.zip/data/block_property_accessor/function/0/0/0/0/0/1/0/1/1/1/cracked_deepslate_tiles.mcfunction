data modify storage block_property_accessor: id set value "minecraft:cracked_deepslate_tiles"
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/1/0/1/1/1/cracked_deepslate_tiles_traits
