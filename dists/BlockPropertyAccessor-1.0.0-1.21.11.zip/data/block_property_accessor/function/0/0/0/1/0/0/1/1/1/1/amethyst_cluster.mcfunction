data modify storage block_property_accessor: id set value "minecraft:amethyst_cluster"
execute if block ~ ~ ~ minecraft:amethyst_cluster[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:amethyst_cluster[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:amethyst_cluster[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:amethyst_cluster[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:amethyst_cluster[facing=up] run data modify storage block_property_accessor: properties.facing set value up
execute if block ~ ~ ~ minecraft:amethyst_cluster[facing=down] run data modify storage block_property_accessor: properties.facing set value down
execute if block ~ ~ ~ minecraft:amethyst_cluster[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:amethyst_cluster[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/0/1/1/1/1/amethyst_cluster_traits
