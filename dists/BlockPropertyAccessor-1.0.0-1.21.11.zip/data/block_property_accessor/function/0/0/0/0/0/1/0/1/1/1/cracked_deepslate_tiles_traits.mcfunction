data modify storage block_property_accessor: traits.blast_resistance set value 6.0f
data modify storage block_property_accessor: traits.hardness set value 3.5f
data modify storage block_property_accessor: traits.slipperiness set value 0.6f
data modify storage block_property_accessor: traits.is_flammable set value false
data modify storage block_property_accessor: traits.is_burnable set value false
data modify storage block_property_accessor: traits.is_occluding set value true
data modify storage block_property_accessor: traits.is_solid set value true
data modify storage block_property_accessor: traits.has_collision set value true
data modify storage block_property_accessor: traits.has_gravity set value false
data modify storage block_property_accessor: traits.is_air set value false
data modify storage block_property_accessor: traits.translation_key set value "block.minecraft.cracked_deepslate_tiles"
data modify storage block_property_accessor: traits.item_type set value "minecraft:cracked_deepslate_tiles"
data modify storage block_property_accessor: traits.light_emission set value "0"
data modify storage block_property_accessor: traits.map_color set value {green: "100", blue: "100", red: "100"}
data modify storage block_property_accessor: traits.sound_group set value {on_place: "minecraft:block.deepslate_tiles.place", volume: 1.0f, on_hit: "minecraft:block.deepslate_tiles.hit", on_step: "minecraft:block.deepslate_tiles.step", on_break: "minecraft:block.deepslate_tiles.break", pitch: 1.0f, on_fall: "minecraft:block.deepslate_tiles.fall"}
data modify storage block_property_accessor: traits.piston_move_reaction set value "move"
data modify storage block_property_accessor: traits.is_replaceable set value false
data modify storage block_property_accessor: traits.is_randomly_ticked set value false
data modify storage block_property_accessor: traits.requires_correct_tool_for_drops set value true
data modify storage block_property_accessor: traits.loot_table set value "minecraft:blocks/cracked_deepslate_tiles"
data modify storage block_property_accessor: traits.speed_factor set value 1.0f
data modify storage block_property_accessor: traits.jump_factor set value 1.0f
