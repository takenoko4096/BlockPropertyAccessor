execute if block ~ ~ ~ minecraft:nether_brick_stairs run function block_property_accessor:0/0/0/1/0/1/0/0/0/nether_brick_stairs
execute if block ~ ~ ~ minecraft:purple_candle run function block_property_accessor:0/0/0/1/0/1/0/0/0/purple_candle
