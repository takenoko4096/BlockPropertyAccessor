data modify storage block_property_accessor: id set value "minecraft:stonecutter"
execute if block ~ ~ ~ minecraft:stonecutter[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:stonecutter[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:stonecutter[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:stonecutter[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/0/1/1/1/0/stonecutter_traits
