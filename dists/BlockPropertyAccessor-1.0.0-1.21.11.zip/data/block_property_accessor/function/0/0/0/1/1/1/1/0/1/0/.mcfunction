execute if block ~ ~ ~ minecraft:acacia_door run function block_property_accessor:0/0/0/1/1/1/1/0/1/0/acacia_door
