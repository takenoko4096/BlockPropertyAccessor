execute if block ~ ~ ~ minecraft:light_blue_bed run function block_property_accessor:0/0/0/1/0/0/0/0/1/light_blue_bed
execute if block ~ ~ ~ minecraft:oak_wall_hanging_sign run function block_property_accessor:0/0/0/1/0/0/0/0/1/oak_wall_hanging_sign
