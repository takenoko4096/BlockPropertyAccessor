data modify storage block_property_accessor: id set value "minecraft:potted_flowering_azalea_bush"
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/1/0/0/1/potted_flowering_azalea_bush_traits
