execute if block ~ ~ ~ minecraft:flowering_azalea_leaves run function block_property_accessor:0/0/0/1/1/0/0/1/0/flowering_azalea_leaves
execute if block ~ ~ ~ minecraft:pink_glazed_terracotta run function block_property_accessor:0/0/0/1/1/0/0/1/0/pink_glazed_terracotta
