data modify storage block_property_accessor: id set value "minecraft:tripwire"
execute if block ~ ~ ~ minecraft:tripwire[attached=true] run data modify storage block_property_accessor: properties.attached set value true
execute if block ~ ~ ~ minecraft:tripwire[attached=false] run data modify storage block_property_accessor: properties.attached set value false
execute if block ~ ~ ~ minecraft:tripwire[disarmed=true] run data modify storage block_property_accessor: properties.disarmed set value true
execute if block ~ ~ ~ minecraft:tripwire[disarmed=false] run data modify storage block_property_accessor: properties.disarmed set value false
execute if block ~ ~ ~ minecraft:tripwire[east=true] run data modify storage block_property_accessor: properties.east set value true
execute if block ~ ~ ~ minecraft:tripwire[east=false] run data modify storage block_property_accessor: properties.east set value false
execute if block ~ ~ ~ minecraft:tripwire[north=true] run data modify storage block_property_accessor: properties.north set value true
execute if block ~ ~ ~ minecraft:tripwire[north=false] run data modify storage block_property_accessor: properties.north set value false
execute if block ~ ~ ~ minecraft:tripwire[powered=true] run data modify storage block_property_accessor: properties.powered set value true
execute if block ~ ~ ~ minecraft:tripwire[powered=false] run data modify storage block_property_accessor: properties.powered set value false
execute if block ~ ~ ~ minecraft:tripwire[south=true] run data modify storage block_property_accessor: properties.south set value true
execute if block ~ ~ ~ minecraft:tripwire[south=false] run data modify storage block_property_accessor: properties.south set value false
execute if block ~ ~ ~ minecraft:tripwire[west=true] run data modify storage block_property_accessor: properties.west set value true
execute if block ~ ~ ~ minecraft:tripwire[west=false] run data modify storage block_property_accessor: properties.west set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/1/1/1/1/1/tripwire_traits
