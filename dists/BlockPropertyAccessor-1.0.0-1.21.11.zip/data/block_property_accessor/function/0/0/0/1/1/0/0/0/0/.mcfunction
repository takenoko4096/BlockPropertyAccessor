execute if block ~ ~ ~ minecraft:dragon_head run function block_property_accessor:0/0/0/1/1/0/0/0/0/dragon_head
execute if block ~ ~ ~ minecraft:honey_block run function block_property_accessor:0/0/0/1/1/0/0/0/0/honey_block
