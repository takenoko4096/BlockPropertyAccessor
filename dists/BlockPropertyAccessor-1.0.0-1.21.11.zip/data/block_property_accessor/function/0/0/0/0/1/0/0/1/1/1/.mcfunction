execute if block ~ ~ ~ minecraft:weathered_copper_lantern run function block_property_accessor:0/0/0/0/1/0/0/1/1/1/weathered_copper_lantern
execute if block ~ ~ ~ minecraft:cobblestone_wall run function block_property_accessor:0/0/0/0/1/0/0/1/1/1/cobblestone_wall
