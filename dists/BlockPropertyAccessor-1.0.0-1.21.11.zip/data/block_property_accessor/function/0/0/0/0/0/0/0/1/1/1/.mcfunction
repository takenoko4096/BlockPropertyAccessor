execute if block ~ ~ ~ minecraft:pale_oak_door run function block_property_accessor:0/0/0/0/0/0/0/1/1/1/pale_oak_door
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest run function block_property_accessor:0/0/0/0/0/0/0/1/1/1/waxed_oxidized_copper_chest
