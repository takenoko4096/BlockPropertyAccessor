data modify storage block_property_accessor: id set value "minecraft:bone_block"
execute if block ~ ~ ~ minecraft:bone_block[axis=x] run data modify storage block_property_accessor: properties.axis set value x
execute if block ~ ~ ~ minecraft:bone_block[axis=y] run data modify storage block_property_accessor: properties.axis set value y
execute if block ~ ~ ~ minecraft:bone_block[axis=z] run data modify storage block_property_accessor: properties.axis set value z
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/1/0/0/0/bone_block_traits
