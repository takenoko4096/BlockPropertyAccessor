execute if block ~ ~ ~ minecraft:bamboo_mosaic run function block_property_accessor:0/0/0/1/0/0/0/1/0/bamboo_mosaic
execute if block ~ ~ ~ minecraft:oak_wood run function block_property_accessor:0/0/0/1/0/0/0/1/0/oak_wood
