execute if block ~ ~ ~ minecraft:tall_grass run function block_property_accessor:0/0/0/0/0/1/1/0/1/tall_grass
execute if block ~ ~ ~ minecraft:warped_fence_gate run function block_property_accessor:0/0/0/0/0/1/1/0/1/warped_fence_gate
