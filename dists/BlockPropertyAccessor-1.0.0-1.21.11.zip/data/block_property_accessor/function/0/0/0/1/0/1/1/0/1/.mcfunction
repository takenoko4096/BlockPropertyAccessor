execute if block ~ ~ ~ minecraft:spruce_fence run function block_property_accessor:0/0/0/1/0/1/1/0/1/spruce_fence
execute if block ~ ~ ~ minecraft:cherry_fence run function block_property_accessor:0/0/0/1/0/1/1/0/1/cherry_fence
