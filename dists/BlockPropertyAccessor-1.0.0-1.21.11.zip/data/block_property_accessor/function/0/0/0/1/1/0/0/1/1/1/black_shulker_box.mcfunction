data modify storage block_property_accessor: id set value "minecraft:black_shulker_box"
execute if block ~ ~ ~ minecraft:black_shulker_box[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:black_shulker_box[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:black_shulker_box[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:black_shulker_box[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:black_shulker_box[facing=up] run data modify storage block_property_accessor: properties.facing set value up
execute if block ~ ~ ~ minecraft:black_shulker_box[facing=down] run data modify storage block_property_accessor: properties.facing set value down
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/0/0/1/1/1/black_shulker_box_traits
