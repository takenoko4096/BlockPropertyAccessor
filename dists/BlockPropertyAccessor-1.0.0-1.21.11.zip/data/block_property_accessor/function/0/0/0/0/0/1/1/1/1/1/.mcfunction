execute if block ~ ~ ~ minecraft:red_mushroom_block run function block_property_accessor:0/0/0/0/0/1/1/1/1/1/red_mushroom_block
execute if block ~ ~ ~ minecraft:nether_wart_block run function block_property_accessor:0/0/0/0/0/1/1/1/1/1/nether_wart_block
