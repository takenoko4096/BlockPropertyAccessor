execute if block ~ ~ ~ minecraft:cornflower run function block_property_accessor:0/0/0/0/0/1/1/1/0/cornflower
execute if block ~ ~ ~ minecraft:red_mushroom run function block_property_accessor:0/0/0/0/0/1/1/1/0/red_mushroom
