execute if block ~ ~ ~ minecraft:scaffolding run function block_property_accessor:0/0/0/1/0/0/0/1/1/0/scaffolding
