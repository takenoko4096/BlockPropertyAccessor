execute if block ~ ~ ~ minecraft:bamboo_fence_gate run function block_property_accessor:0/0/0/0/1/0/0/0/0/bamboo_fence_gate
execute if block ~ ~ ~ minecraft:dead_brain_coral_wall_fan run function block_property_accessor:0/0/0/0/1/0/0/0/0/dead_brain_coral_wall_fan
