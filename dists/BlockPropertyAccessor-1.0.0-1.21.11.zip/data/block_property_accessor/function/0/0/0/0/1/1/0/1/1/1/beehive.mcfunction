data modify storage block_property_accessor: id set value "minecraft:beehive"
execute if block ~ ~ ~ minecraft:beehive[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:beehive[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:beehive[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:beehive[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:beehive[honey_level=0] run data modify storage block_property_accessor: properties.honey_level set value 0
execute if block ~ ~ ~ minecraft:beehive[honey_level=1] run data modify storage block_property_accessor: properties.honey_level set value 1
execute if block ~ ~ ~ minecraft:beehive[honey_level=2] run data modify storage block_property_accessor: properties.honey_level set value 2
execute if block ~ ~ ~ minecraft:beehive[honey_level=3] run data modify storage block_property_accessor: properties.honey_level set value 3
execute if block ~ ~ ~ minecraft:beehive[honey_level=4] run data modify storage block_property_accessor: properties.honey_level set value 4
execute if block ~ ~ ~ minecraft:beehive[honey_level=5] run data modify storage block_property_accessor: properties.honey_level set value 5
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/1/0/1/1/1/beehive_traits
