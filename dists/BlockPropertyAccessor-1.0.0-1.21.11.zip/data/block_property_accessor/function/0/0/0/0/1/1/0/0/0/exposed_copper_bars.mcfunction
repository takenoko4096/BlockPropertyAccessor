data modify storage block_property_accessor: id set value "minecraft:exposed_copper_bars"
execute if block ~ ~ ~ minecraft:exposed_copper_bars[east=true] run data modify storage block_property_accessor: properties.east set value true
execute if block ~ ~ ~ minecraft:exposed_copper_bars[east=false] run data modify storage block_property_accessor: properties.east set value false
execute if block ~ ~ ~ minecraft:exposed_copper_bars[north=true] run data modify storage block_property_accessor: properties.north set value true
execute if block ~ ~ ~ minecraft:exposed_copper_bars[north=false] run data modify storage block_property_accessor: properties.north set value false
execute if block ~ ~ ~ minecraft:exposed_copper_bars[south=true] run data modify storage block_property_accessor: properties.south set value true
execute if block ~ ~ ~ minecraft:exposed_copper_bars[south=false] run data modify storage block_property_accessor: properties.south set value false
execute if block ~ ~ ~ minecraft:exposed_copper_bars[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:exposed_copper_bars[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if block ~ ~ ~ minecraft:exposed_copper_bars[west=true] run data modify storage block_property_accessor: properties.west set value true
execute if block ~ ~ ~ minecraft:exposed_copper_bars[west=false] run data modify storage block_property_accessor: properties.west set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/1/0/0/0/exposed_copper_bars_traits
