execute if block ~ ~ ~ minecraft:lilac run function block_property_accessor:0/0/0/1/0/1/0/1/0/lilac
execute if block ~ ~ ~ minecraft:open_eyeblossom run function block_property_accessor:0/0/0/1/0/1/0/1/0/open_eyeblossom
