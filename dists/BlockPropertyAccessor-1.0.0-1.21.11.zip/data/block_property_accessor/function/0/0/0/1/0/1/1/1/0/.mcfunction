execute if block ~ ~ ~ minecraft:polished_tuff_slab run function block_property_accessor:0/0/0/1/0/1/1/1/0/polished_tuff_slab
execute if block ~ ~ ~ minecraft:diamond_ore run function block_property_accessor:0/0/0/1/0/1/1/1/0/diamond_ore
