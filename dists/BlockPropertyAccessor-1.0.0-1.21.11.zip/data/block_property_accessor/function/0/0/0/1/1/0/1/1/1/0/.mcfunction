execute if block ~ ~ ~ minecraft:cut_sandstone_slab run function block_property_accessor:0/0/0/1/1/0/1/1/1/0/cut_sandstone_slab
