data modify storage block_property_accessor: id set value "minecraft:waxed_oxidized_copper_chest"
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest[type=single] run data modify storage block_property_accessor: properties.type set value single
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest[type=left] run data modify storage block_property_accessor: properties.type set value left
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest[type=right] run data modify storage block_property_accessor: properties.type set value right
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chest[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/0/0/1/1/1/waxed_oxidized_copper_chest_traits
