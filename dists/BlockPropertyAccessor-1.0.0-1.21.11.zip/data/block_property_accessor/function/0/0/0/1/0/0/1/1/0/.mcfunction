execute if block ~ ~ ~ minecraft:potted_red_mushroom run function block_property_accessor:0/0/0/1/0/0/1/1/0/potted_red_mushroom
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane run function block_property_accessor:0/0/0/1/0/0/1/1/0/magenta_stained_glass_pane
