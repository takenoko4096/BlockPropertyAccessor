data modify storage block_property_accessor: id set value "minecraft:waxed_oxidized_copper_chain"
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chain[axis=x] run data modify storage block_property_accessor: properties.axis set value x
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chain[axis=y] run data modify storage block_property_accessor: properties.axis set value y
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chain[axis=z] run data modify storage block_property_accessor: properties.axis set value z
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chain[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:waxed_oxidized_copper_chain[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/1/0/1/1/1/waxed_oxidized_copper_chain_traits
