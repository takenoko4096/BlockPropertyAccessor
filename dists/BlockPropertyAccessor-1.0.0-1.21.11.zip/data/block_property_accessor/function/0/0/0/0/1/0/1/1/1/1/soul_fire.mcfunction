data modify storage block_property_accessor: id set value "minecraft:soul_fire"
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/0/1/1/1/1/soul_fire_traits
