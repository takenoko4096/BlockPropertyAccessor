data modify storage block_property_accessor: id set value "minecraft:stripped_dark_oak_wood"
execute if block ~ ~ ~ minecraft:stripped_dark_oak_wood[axis=x] run data modify storage block_property_accessor: properties.axis set value x
execute if block ~ ~ ~ minecraft:stripped_dark_oak_wood[axis=y] run data modify storage block_property_accessor: properties.axis set value y
execute if block ~ ~ ~ minecraft:stripped_dark_oak_wood[axis=z] run data modify storage block_property_accessor: properties.axis set value z
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/0/1/1/0/stripped_dark_oak_wood_traits
