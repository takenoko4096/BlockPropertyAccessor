data modify storage block_property_accessor: id set value "minecraft:magenta_banner"
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=0] run data modify storage block_property_accessor: properties.rotation set value 0
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=1] run data modify storage block_property_accessor: properties.rotation set value 1
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=2] run data modify storage block_property_accessor: properties.rotation set value 2
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=3] run data modify storage block_property_accessor: properties.rotation set value 3
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=4] run data modify storage block_property_accessor: properties.rotation set value 4
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=5] run data modify storage block_property_accessor: properties.rotation set value 5
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=6] run data modify storage block_property_accessor: properties.rotation set value 6
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=7] run data modify storage block_property_accessor: properties.rotation set value 7
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=8] run data modify storage block_property_accessor: properties.rotation set value 8
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=9] run data modify storage block_property_accessor: properties.rotation set value 9
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=10] run data modify storage block_property_accessor: properties.rotation set value 10
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=11] run data modify storage block_property_accessor: properties.rotation set value 11
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=12] run data modify storage block_property_accessor: properties.rotation set value 12
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=13] run data modify storage block_property_accessor: properties.rotation set value 13
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=14] run data modify storage block_property_accessor: properties.rotation set value 14
execute if block ~ ~ ~ minecraft:magenta_banner[rotation=15] run data modify storage block_property_accessor: properties.rotation set value 15
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/0/0/1/0/magenta_banner_traits
