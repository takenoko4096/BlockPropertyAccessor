execute if block ~ ~ ~ minecraft:amethyst_cluster run function block_property_accessor:0/0/0/1/0/0/1/1/1/1/amethyst_cluster
execute if block ~ ~ ~ minecraft:potted_open_eyeblossom run function block_property_accessor:0/0/0/1/0/0/1/1/1/1/potted_open_eyeblossom
