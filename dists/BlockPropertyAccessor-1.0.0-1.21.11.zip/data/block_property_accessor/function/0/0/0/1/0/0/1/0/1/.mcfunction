execute if block ~ ~ ~ minecraft:cocoa run function block_property_accessor:0/0/0/1/0/0/1/0/1/cocoa
execute if block ~ ~ ~ minecraft:acacia_button run function block_property_accessor:0/0/0/1/0/0/1/0/1/acacia_button
