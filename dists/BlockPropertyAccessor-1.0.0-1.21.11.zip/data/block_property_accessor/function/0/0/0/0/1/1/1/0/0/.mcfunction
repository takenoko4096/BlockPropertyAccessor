execute if block ~ ~ ~ minecraft:spruce_sign run function block_property_accessor:0/0/0/0/1/1/1/0/0/spruce_sign
execute if block ~ ~ ~ minecraft:dead_tube_coral_fan run function block_property_accessor:0/0/0/0/1/1/1/0/0/dead_tube_coral_fan
