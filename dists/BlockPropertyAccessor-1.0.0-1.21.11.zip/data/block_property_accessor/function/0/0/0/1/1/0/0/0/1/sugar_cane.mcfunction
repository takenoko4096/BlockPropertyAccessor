data modify storage block_property_accessor: id set value "minecraft:sugar_cane"
execute if block ~ ~ ~ minecraft:sugar_cane[age=0] run data modify storage block_property_accessor: properties.age set value 0
execute if block ~ ~ ~ minecraft:sugar_cane[age=1] run data modify storage block_property_accessor: properties.age set value 1
execute if block ~ ~ ~ minecraft:sugar_cane[age=2] run data modify storage block_property_accessor: properties.age set value 2
execute if block ~ ~ ~ minecraft:sugar_cane[age=3] run data modify storage block_property_accessor: properties.age set value 3
execute if block ~ ~ ~ minecraft:sugar_cane[age=4] run data modify storage block_property_accessor: properties.age set value 4
execute if block ~ ~ ~ minecraft:sugar_cane[age=5] run data modify storage block_property_accessor: properties.age set value 5
execute if block ~ ~ ~ minecraft:sugar_cane[age=6] run data modify storage block_property_accessor: properties.age set value 6
execute if block ~ ~ ~ minecraft:sugar_cane[age=7] run data modify storage block_property_accessor: properties.age set value 7
execute if block ~ ~ ~ minecraft:sugar_cane[age=8] run data modify storage block_property_accessor: properties.age set value 8
execute if block ~ ~ ~ minecraft:sugar_cane[age=9] run data modify storage block_property_accessor: properties.age set value 9
execute if block ~ ~ ~ minecraft:sugar_cane[age=10] run data modify storage block_property_accessor: properties.age set value 10
execute if block ~ ~ ~ minecraft:sugar_cane[age=11] run data modify storage block_property_accessor: properties.age set value 11
execute if block ~ ~ ~ minecraft:sugar_cane[age=12] run data modify storage block_property_accessor: properties.age set value 12
execute if block ~ ~ ~ minecraft:sugar_cane[age=13] run data modify storage block_property_accessor: properties.age set value 13
execute if block ~ ~ ~ minecraft:sugar_cane[age=14] run data modify storage block_property_accessor: properties.age set value 14
execute if block ~ ~ ~ minecraft:sugar_cane[age=15] run data modify storage block_property_accessor: properties.age set value 15
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/0/0/0/1/sugar_cane_traits
