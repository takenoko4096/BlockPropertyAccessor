execute if block ~ ~ ~ minecraft:exposed_cut_copper_slab run function block_property_accessor:0/0/0/1/1/0/1/0/1/exposed_cut_copper_slab
execute if block ~ ~ ~ minecraft:magenta_concrete run function block_property_accessor:0/0/0/1/1/0/1/0/1/magenta_concrete
