data modify storage block_property_accessor: id set value "minecraft:waxed_exposed_cut_copper_stairs"
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[half=top] run data modify storage block_property_accessor: properties.half set value top
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[half=bottom] run data modify storage block_property_accessor: properties.half set value bottom
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[shape=straight] run data modify storage block_property_accessor: properties.shape set value straight
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[shape=inner_left] run data modify storage block_property_accessor: properties.shape set value inner_left
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[shape=inner_right] run data modify storage block_property_accessor: properties.shape set value inner_right
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[shape=outer_left] run data modify storage block_property_accessor: properties.shape set value outer_left
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[shape=outer_right] run data modify storage block_property_accessor: properties.shape set value outer_right
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/0/1/0/0/waxed_exposed_cut_copper_stairs_traits
