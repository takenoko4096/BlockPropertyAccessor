execute if block ~ ~ ~ minecraft:soul_fire run function block_property_accessor:0/0/0/0/1/0/1/1/1/1/soul_fire
execute if block ~ ~ ~ minecraft:closed_eyeblossom run function block_property_accessor:0/0/0/0/1/0/1/1/1/1/closed_eyeblossom
