data modify storage block_property_accessor: id set value "minecraft:bamboo_pressure_plate"
execute if block ~ ~ ~ minecraft:bamboo_pressure_plate[powered=true] run data modify storage block_property_accessor: properties.powered set value true
execute if block ~ ~ ~ minecraft:bamboo_pressure_plate[powered=false] run data modify storage block_property_accessor: properties.powered set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/1/0/0/1/bamboo_pressure_plate_traits
