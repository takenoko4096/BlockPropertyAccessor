execute if block ~ ~ ~ minecraft:basalt run function block_property_accessor:0/0/0/0/0/0/0/1/1/0/basalt
