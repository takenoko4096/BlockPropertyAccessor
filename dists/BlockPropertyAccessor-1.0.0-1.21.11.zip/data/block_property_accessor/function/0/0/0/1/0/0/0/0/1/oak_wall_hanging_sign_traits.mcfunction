data modify storage block_property_accessor: traits.blast_resistance set value 1.0f
data modify storage block_property_accessor: traits.hardness set value 1.0f
data modify storage block_property_accessor: traits.slipperiness set value 0.6f
data modify storage block_property_accessor: traits.is_flammable set value true
data modify storage block_property_accessor: traits.is_burnable set value false
data modify storage block_property_accessor: traits.is_occluding set value false
data modify storage block_property_accessor: traits.is_solid set value true
data modify storage block_property_accessor: traits.has_collision set value false
data modify storage block_property_accessor: traits.has_gravity set value false
data modify storage block_property_accessor: traits.is_air set value false
data modify storage block_property_accessor: traits.translation_key set value "block.minecraft.oak_hanging_sign"
data modify storage block_property_accessor: traits.item_type set value "minecraft:oak_hanging_sign"
data modify storage block_property_accessor: traits.light_emission set value "0"
data modify storage block_property_accessor: traits.map_color set value {red: "143", blue: "72", green: "119"}
data modify storage block_property_accessor: traits.sound_group set value {on_hit: "minecraft:block.hanging_sign.hit", on_break: "minecraft:block.hanging_sign.break", volume: 1.0f, on_place: "minecraft:block.hanging_sign.place", on_fall: "minecraft:block.hanging_sign.fall", on_step: "minecraft:block.hanging_sign.step", pitch: 1.0f}
data modify storage block_property_accessor: traits.piston_move_reaction set value "move"
data modify storage block_property_accessor: traits.is_replaceable set value false
data modify storage block_property_accessor: traits.is_randomly_ticked set value false
data modify storage block_property_accessor: traits.requires_correct_tool_for_drops set value false
data modify storage block_property_accessor: traits.loot_table set value "minecraft:blocks/oak_hanging_sign"
data modify storage block_property_accessor: traits.speed_factor set value 1.0f
data modify storage block_property_accessor: traits.jump_factor set value 1.0f
