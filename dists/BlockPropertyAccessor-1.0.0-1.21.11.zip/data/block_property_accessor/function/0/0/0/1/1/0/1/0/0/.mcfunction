execute if block ~ ~ ~ minecraft:waxed_exposed_cut_copper_stairs run function block_property_accessor:0/0/0/1/1/0/1/0/0/waxed_exposed_cut_copper_stairs
execute if block ~ ~ ~ minecraft:orange_stained_glass run function block_property_accessor:0/0/0/1/1/0/1/0/0/orange_stained_glass
