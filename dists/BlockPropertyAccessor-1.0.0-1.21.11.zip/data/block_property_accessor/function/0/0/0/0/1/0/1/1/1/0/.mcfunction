execute if block ~ ~ ~ minecraft:large_fern run function block_property_accessor:0/0/0/0/1/0/1/1/1/0/large_fern
