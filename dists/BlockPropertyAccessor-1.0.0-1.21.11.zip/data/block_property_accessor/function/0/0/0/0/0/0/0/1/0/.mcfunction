execute if block ~ ~ ~ minecraft:polished_blackstone_brick_slab run function block_property_accessor:0/0/0/0/0/0/0/1/0/polished_blackstone_brick_slab
execute if block ~ ~ ~ minecraft:cherry_sapling run function block_property_accessor:0/0/0/0/0/0/0/1/0/cherry_sapling
