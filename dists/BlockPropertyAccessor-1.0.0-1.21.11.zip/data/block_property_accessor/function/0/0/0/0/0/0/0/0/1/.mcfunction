execute if block ~ ~ ~ minecraft:oxidized_copper_lantern run function block_property_accessor:0/0/0/0/0/0/0/0/1/oxidized_copper_lantern
execute if block ~ ~ ~ minecraft:structure_block run function block_property_accessor:0/0/0/0/0/0/0/0/1/structure_block
