data modify storage block_property_accessor: id set value "minecraft:yellow_bed"
execute if block ~ ~ ~ minecraft:yellow_bed[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:yellow_bed[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:yellow_bed[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:yellow_bed[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:yellow_bed[occupied=true] run data modify storage block_property_accessor: properties.occupied set value true
execute if block ~ ~ ~ minecraft:yellow_bed[occupied=false] run data modify storage block_property_accessor: properties.occupied set value false
execute if block ~ ~ ~ minecraft:yellow_bed[part=head] run data modify storage block_property_accessor: properties.part set value head
execute if block ~ ~ ~ minecraft:yellow_bed[part=foot] run data modify storage block_property_accessor: properties.part set value foot
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/1/0/1/1/0/yellow_bed_traits
