execute if block ~ ~ ~ minecraft:dark_oak_button run function block_property_accessor:0/0/0/0/0/0/0/0/0/dark_oak_button
execute if block ~ ~ ~ minecraft:wall_torch run function block_property_accessor:0/0/0/0/0/0/0/0/0/wall_torch
