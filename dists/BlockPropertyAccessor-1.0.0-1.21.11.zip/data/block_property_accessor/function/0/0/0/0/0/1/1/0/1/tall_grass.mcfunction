data modify storage block_property_accessor: id set value "minecraft:tall_grass"
execute if block ~ ~ ~ minecraft:tall_grass[half=upper] run data modify storage block_property_accessor: properties.half set value upper
execute if block ~ ~ ~ minecraft:tall_grass[half=lower] run data modify storage block_property_accessor: properties.half set value lower
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/1/1/0/1/tall_grass_traits
