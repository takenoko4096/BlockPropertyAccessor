execute if block ~ ~ ~ minecraft:mangrove_fence_gate run function block_property_accessor:0/0/0/0/1/0/1/0/1/mangrove_fence_gate
execute if block ~ ~ ~ minecraft:warped_pressure_plate run function block_property_accessor:0/0/0/0/1/0/1/0/1/warped_pressure_plate
