data modify storage block_property_accessor: id set value "minecraft:structure_block"
execute if block ~ ~ ~ minecraft:structure_block[mode=save] run data modify storage block_property_accessor: properties.mode set value save
execute if block ~ ~ ~ minecraft:structure_block[mode=load] run data modify storage block_property_accessor: properties.mode set value load
execute if block ~ ~ ~ minecraft:structure_block[mode=corner] run data modify storage block_property_accessor: properties.mode set value corner
execute if block ~ ~ ~ minecraft:structure_block[mode=data] run data modify storage block_property_accessor: properties.mode set value data
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/0/0/0/1/structure_block_traits
