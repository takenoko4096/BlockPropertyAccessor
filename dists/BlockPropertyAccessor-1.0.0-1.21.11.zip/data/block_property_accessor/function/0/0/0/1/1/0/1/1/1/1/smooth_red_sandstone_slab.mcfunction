data modify storage block_property_accessor: id set value "minecraft:smooth_red_sandstone_slab"
execute if block ~ ~ ~ minecraft:smooth_red_sandstone_slab[type=top] run data modify storage block_property_accessor: properties.type set value top
execute if block ~ ~ ~ minecraft:smooth_red_sandstone_slab[type=bottom] run data modify storage block_property_accessor: properties.type set value bottom
execute if block ~ ~ ~ minecraft:smooth_red_sandstone_slab[type=double] run data modify storage block_property_accessor: properties.type set value double
execute if block ~ ~ ~ minecraft:smooth_red_sandstone_slab[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:smooth_red_sandstone_slab[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/0/1/1/1/1/smooth_red_sandstone_slab_traits
