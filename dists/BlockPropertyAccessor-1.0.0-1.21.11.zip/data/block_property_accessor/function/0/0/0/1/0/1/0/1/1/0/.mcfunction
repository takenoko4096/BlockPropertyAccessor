execute if block ~ ~ ~ minecraft:purple_wool run function block_property_accessor:0/0/0/1/0/1/0/1/1/0/purple_wool
