data modify storage block_property_accessor: id set value "minecraft:oxidized_copper_grate"
execute if block ~ ~ ~ minecraft:oxidized_copper_grate[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:oxidized_copper_grate[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/0/0/1/1/1/oxidized_copper_grate_traits
