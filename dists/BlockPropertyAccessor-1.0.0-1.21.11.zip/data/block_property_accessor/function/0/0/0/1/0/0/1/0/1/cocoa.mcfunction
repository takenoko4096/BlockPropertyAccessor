data modify storage block_property_accessor: id set value "minecraft:cocoa"
execute if block ~ ~ ~ minecraft:cocoa[age=0] run data modify storage block_property_accessor: properties.age set value 0
execute if block ~ ~ ~ minecraft:cocoa[age=1] run data modify storage block_property_accessor: properties.age set value 1
execute if block ~ ~ ~ minecraft:cocoa[age=2] run data modify storage block_property_accessor: properties.age set value 2
execute if block ~ ~ ~ minecraft:cocoa[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:cocoa[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:cocoa[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:cocoa[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/0/1/0/1/cocoa_traits
