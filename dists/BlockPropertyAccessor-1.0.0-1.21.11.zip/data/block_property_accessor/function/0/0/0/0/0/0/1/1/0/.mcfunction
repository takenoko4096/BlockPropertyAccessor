execute if block ~ ~ ~ minecraft:chiseled_tuff_bricks run function block_property_accessor:0/0/0/0/0/0/1/1/0/chiseled_tuff_bricks
execute if block ~ ~ ~ minecraft:stripped_dark_oak_wood run function block_property_accessor:0/0/0/0/0/0/1/1/0/stripped_dark_oak_wood
