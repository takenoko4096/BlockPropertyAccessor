execute if block ~ ~ ~ minecraft:bamboo_planks run function block_property_accessor:0/0/0/1/1/0/0/0/1/bamboo_planks
execute if block ~ ~ ~ minecraft:sugar_cane run function block_property_accessor:0/0/0/1/1/0/0/0/1/sugar_cane
