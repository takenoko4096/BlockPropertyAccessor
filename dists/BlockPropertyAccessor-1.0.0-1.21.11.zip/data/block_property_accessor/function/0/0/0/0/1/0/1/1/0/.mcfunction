execute if block ~ ~ ~ minecraft:waxed_cut_copper_slab run function block_property_accessor:0/0/0/0/1/0/1/1/0/waxed_cut_copper_slab
execute if block ~ ~ ~ minecraft:coal_block run function block_property_accessor:0/0/0/0/1/0/1/1/0/coal_block
