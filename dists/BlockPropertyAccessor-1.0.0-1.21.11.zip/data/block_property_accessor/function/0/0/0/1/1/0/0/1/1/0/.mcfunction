execute if block ~ ~ ~ minecraft:pink_terracotta run function block_property_accessor:0/0/0/1/1/0/0/1/1/0/pink_terracotta
