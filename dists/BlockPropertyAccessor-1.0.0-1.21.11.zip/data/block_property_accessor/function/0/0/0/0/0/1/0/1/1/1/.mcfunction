execute if block ~ ~ ~ minecraft:cracked_deepslate_tiles run function block_property_accessor:0/0/0/0/0/1/0/1/1/1/cracked_deepslate_tiles
execute if block ~ ~ ~ minecraft:red_nether_brick_slab run function block_property_accessor:0/0/0/0/0/1/0/1/1/1/red_nether_brick_slab
