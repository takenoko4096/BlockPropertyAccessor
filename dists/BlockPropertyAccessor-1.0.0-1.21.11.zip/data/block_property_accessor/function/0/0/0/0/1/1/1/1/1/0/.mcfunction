execute if block ~ ~ ~ minecraft:big_dripleaf run function block_property_accessor:0/0/0/0/1/1/1/1/1/0/big_dripleaf
