execute if block ~ ~ ~ minecraft:redstone_ore run function block_property_accessor:0/0/0/1/1/1/1/1/0/redstone_ore
execute if block ~ ~ ~ minecraft:polished_basalt run function block_property_accessor:0/0/0/1/1/1/1/1/0/polished_basalt
