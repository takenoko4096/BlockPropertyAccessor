execute if block ~ ~ ~ minecraft:lapis_ore run function block_property_accessor:0/0/0/0/1/1/1/1/0/lapis_ore
execute if block ~ ~ ~ minecraft:gravel run function block_property_accessor:0/0/0/0/1/1/1/1/0/gravel
