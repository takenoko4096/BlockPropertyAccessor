execute if block ~ ~ ~ minecraft:iron_block run function block_property_accessor:0/0/0/0/1/1/0/1/1/1/iron_block
execute if block ~ ~ ~ minecraft:beehive run function block_property_accessor:0/0/0/0/1/1/0/1/1/1/beehive
