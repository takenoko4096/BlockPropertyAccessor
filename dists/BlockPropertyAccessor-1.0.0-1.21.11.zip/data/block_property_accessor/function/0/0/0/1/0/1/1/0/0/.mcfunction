execute if block ~ ~ ~ minecraft:spruce_wood run function block_property_accessor:0/0/0/1/0/1/1/0/0/spruce_wood
execute if block ~ ~ ~ minecraft:green_stained_glass run function block_property_accessor:0/0/0/1/0/1/1/0/0/green_stained_glass
