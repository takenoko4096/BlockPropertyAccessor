execute if block ~ ~ ~ minecraft:dark_oak_door run function block_property_accessor:0/0/0/0/1/1/1/0/1/dark_oak_door
execute if block ~ ~ ~ minecraft:blackstone run function block_property_accessor:0/0/0/0/1/1/1/0/1/blackstone
