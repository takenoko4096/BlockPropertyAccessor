data modify storage block_property_accessor: id set value "minecraft:red_mushroom_block"
execute if block ~ ~ ~ minecraft:red_mushroom_block[down=true] run data modify storage block_property_accessor: properties.down set value true
execute if block ~ ~ ~ minecraft:red_mushroom_block[down=false] run data modify storage block_property_accessor: properties.down set value false
execute if block ~ ~ ~ minecraft:red_mushroom_block[east=true] run data modify storage block_property_accessor: properties.east set value true
execute if block ~ ~ ~ minecraft:red_mushroom_block[east=false] run data modify storage block_property_accessor: properties.east set value false
execute if block ~ ~ ~ minecraft:red_mushroom_block[north=true] run data modify storage block_property_accessor: properties.north set value true
execute if block ~ ~ ~ minecraft:red_mushroom_block[north=false] run data modify storage block_property_accessor: properties.north set value false
execute if block ~ ~ ~ minecraft:red_mushroom_block[south=true] run data modify storage block_property_accessor: properties.south set value true
execute if block ~ ~ ~ minecraft:red_mushroom_block[south=false] run data modify storage block_property_accessor: properties.south set value false
execute if block ~ ~ ~ minecraft:red_mushroom_block[up=true] run data modify storage block_property_accessor: properties.up set value true
execute if block ~ ~ ~ minecraft:red_mushroom_block[up=false] run data modify storage block_property_accessor: properties.up set value false
execute if block ~ ~ ~ minecraft:red_mushroom_block[west=true] run data modify storage block_property_accessor: properties.west set value true
execute if block ~ ~ ~ minecraft:red_mushroom_block[west=false] run data modify storage block_property_accessor: properties.west set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/1/1/1/1/1/red_mushroom_block_traits
