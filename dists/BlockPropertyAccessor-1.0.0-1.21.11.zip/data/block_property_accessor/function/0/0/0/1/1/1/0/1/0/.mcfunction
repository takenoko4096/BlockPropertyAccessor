execute if block ~ ~ ~ minecraft:cherry_door run function block_property_accessor:0/0/0/1/1/1/0/1/0/cherry_door
execute if block ~ ~ ~ minecraft:small_dripleaf run function block_property_accessor:0/0/0/1/1/1/0/1/0/small_dripleaf
