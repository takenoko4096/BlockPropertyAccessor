execute if block ~ ~ ~ minecraft:soul_torch run function block_property_accessor:0/0/0/0/0/0/1/1/1/1/soul_torch
execute if block ~ ~ ~ minecraft:potted_white_tulip run function block_property_accessor:0/0/0/0/0/0/1/1/1/1/potted_white_tulip
