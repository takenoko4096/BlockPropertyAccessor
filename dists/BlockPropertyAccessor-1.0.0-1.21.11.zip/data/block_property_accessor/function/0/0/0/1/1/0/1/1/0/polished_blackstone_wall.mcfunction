data modify storage block_property_accessor: id set value "minecraft:polished_blackstone_wall"
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[east=none] run data modify storage block_property_accessor: properties.east set value none
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[east=low] run data modify storage block_property_accessor: properties.east set value low
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[east=tall] run data modify storage block_property_accessor: properties.east set value tall
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[north=none] run data modify storage block_property_accessor: properties.north set value none
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[north=low] run data modify storage block_property_accessor: properties.north set value low
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[north=tall] run data modify storage block_property_accessor: properties.north set value tall
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[south=none] run data modify storage block_property_accessor: properties.south set value none
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[south=low] run data modify storage block_property_accessor: properties.south set value low
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[south=tall] run data modify storage block_property_accessor: properties.south set value tall
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[up=true] run data modify storage block_property_accessor: properties.up set value true
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[up=false] run data modify storage block_property_accessor: properties.up set value false
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[west=none] run data modify storage block_property_accessor: properties.west set value none
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[west=low] run data modify storage block_property_accessor: properties.west set value low
execute if block ~ ~ ~ minecraft:polished_blackstone_wall[west=tall] run data modify storage block_property_accessor: properties.west set value tall
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/0/1/1/0/polished_blackstone_wall_traits
