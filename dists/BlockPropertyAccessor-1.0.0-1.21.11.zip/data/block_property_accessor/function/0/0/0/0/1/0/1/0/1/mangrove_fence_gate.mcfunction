data modify storage block_property_accessor: id set value "minecraft:mangrove_fence_gate"
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[in_wall=true] run data modify storage block_property_accessor: properties.in_wall set value true
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[in_wall=false] run data modify storage block_property_accessor: properties.in_wall set value false
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[open=true] run data modify storage block_property_accessor: properties.open set value true
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[open=false] run data modify storage block_property_accessor: properties.open set value false
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[powered=true] run data modify storage block_property_accessor: properties.powered set value true
execute if block ~ ~ ~ minecraft:mangrove_fence_gate[powered=false] run data modify storage block_property_accessor: properties.powered set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/0/1/0/1/mangrove_fence_gate_traits
