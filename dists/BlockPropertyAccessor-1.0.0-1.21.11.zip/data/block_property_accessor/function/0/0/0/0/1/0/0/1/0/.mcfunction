execute if block ~ ~ ~ minecraft:magenta_banner run function block_property_accessor:0/0/0/0/1/0/0/1/0/magenta_banner
execute if block ~ ~ ~ minecraft:green_concrete run function block_property_accessor:0/0/0/0/1/0/0/1/0/green_concrete
