execute if block ~ ~ ~ minecraft:oak_wall_sign run function block_property_accessor:0/0/0/0/1/1/0/0/1/oak_wall_sign
execute if block ~ ~ ~ minecraft:mangrove_button run function block_property_accessor:0/0/0/0/1/1/0/0/1/mangrove_button
