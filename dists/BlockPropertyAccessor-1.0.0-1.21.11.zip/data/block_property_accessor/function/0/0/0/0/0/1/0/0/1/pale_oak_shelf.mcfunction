data modify storage block_property_accessor: id set value "minecraft:pale_oak_shelf"
execute if block ~ ~ ~ minecraft:pale_oak_shelf[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:pale_oak_shelf[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:pale_oak_shelf[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:pale_oak_shelf[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:pale_oak_shelf[powered=true] run data modify storage block_property_accessor: properties.powered set value true
execute if block ~ ~ ~ minecraft:pale_oak_shelf[powered=false] run data modify storage block_property_accessor: properties.powered set value false
execute if block ~ ~ ~ minecraft:pale_oak_shelf[side_chain=unconnected] run data modify storage block_property_accessor: properties.side_chain set value unconnected
execute if block ~ ~ ~ minecraft:pale_oak_shelf[side_chain=right] run data modify storage block_property_accessor: properties.side_chain set value right
execute if block ~ ~ ~ minecraft:pale_oak_shelf[side_chain=center] run data modify storage block_property_accessor: properties.side_chain set value center
execute if block ~ ~ ~ minecraft:pale_oak_shelf[side_chain=left] run data modify storage block_property_accessor: properties.side_chain set value left
execute if block ~ ~ ~ minecraft:pale_oak_shelf[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:pale_oak_shelf[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/0/1/0/0/1/pale_oak_shelf_traits
