execute if block ~ ~ ~ minecraft:chiseled_deepslate run function block_property_accessor:0/0/0/0/0/0/1/0/0/chiseled_deepslate
execute if block ~ ~ ~ minecraft:gray_candle run function block_property_accessor:0/0/0/0/0/0/1/0/0/gray_candle
