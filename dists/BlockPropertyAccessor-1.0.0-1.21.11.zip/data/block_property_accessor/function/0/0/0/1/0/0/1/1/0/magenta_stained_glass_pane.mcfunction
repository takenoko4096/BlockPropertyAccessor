data modify storage block_property_accessor: id set value "minecraft:magenta_stained_glass_pane"
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[east=true] run data modify storage block_property_accessor: properties.east set value true
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[east=false] run data modify storage block_property_accessor: properties.east set value false
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[north=true] run data modify storage block_property_accessor: properties.north set value true
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[north=false] run data modify storage block_property_accessor: properties.north set value false
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[south=true] run data modify storage block_property_accessor: properties.south set value true
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[south=false] run data modify storage block_property_accessor: properties.south set value false
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[west=true] run data modify storage block_property_accessor: properties.west set value true
execute if block ~ ~ ~ minecraft:magenta_stained_glass_pane[west=false] run data modify storage block_property_accessor: properties.west set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/0/0/1/1/0/magenta_stained_glass_pane_traits
