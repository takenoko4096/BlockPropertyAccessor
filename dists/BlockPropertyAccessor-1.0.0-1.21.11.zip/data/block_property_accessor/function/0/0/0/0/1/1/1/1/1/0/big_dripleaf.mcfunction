data modify storage block_property_accessor: id set value "minecraft:big_dripleaf"
execute if block ~ ~ ~ minecraft:big_dripleaf[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:big_dripleaf[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:big_dripleaf[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:big_dripleaf[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if block ~ ~ ~ minecraft:big_dripleaf[tilt=none] run data modify storage block_property_accessor: properties.tilt set value none
execute if block ~ ~ ~ minecraft:big_dripleaf[tilt=unstable] run data modify storage block_property_accessor: properties.tilt set value unstable
execute if block ~ ~ ~ minecraft:big_dripleaf[tilt=partial] run data modify storage block_property_accessor: properties.tilt set value partial
execute if block ~ ~ ~ minecraft:big_dripleaf[tilt=full] run data modify storage block_property_accessor: properties.tilt set value full
execute if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=true] run data modify storage block_property_accessor: properties.waterlogged set value true
execute if block ~ ~ ~ minecraft:big_dripleaf[waterlogged=false] run data modify storage block_property_accessor: properties.waterlogged set value false
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/0/1/1/1/1/1/0/big_dripleaf_traits
