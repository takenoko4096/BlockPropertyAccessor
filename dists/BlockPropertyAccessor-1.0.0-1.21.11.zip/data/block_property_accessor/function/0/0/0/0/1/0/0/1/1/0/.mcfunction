execute if block ~ ~ ~ minecraft:creaking_heart run function block_property_accessor:0/0/0/0/1/0/0/1/1/0/creaking_heart
