execute if block ~ ~ ~ minecraft:exposed_copper_bars run function block_property_accessor:0/0/0/0/1/1/0/0/0/exposed_copper_bars
execute if block ~ ~ ~ minecraft:black_wool run function block_property_accessor:0/0/0/0/1/1/0/0/0/black_wool
