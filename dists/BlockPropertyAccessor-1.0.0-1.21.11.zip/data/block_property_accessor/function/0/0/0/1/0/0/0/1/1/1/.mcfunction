execute if block ~ ~ ~ minecraft:emerald_block run function block_property_accessor:0/0/0/1/0/0/0/1/1/1/emerald_block
execute if block ~ ~ ~ minecraft:crimson_fungus run function block_property_accessor:0/0/0/1/0/0/0/1/1/1/crimson_fungus
