data modify storage block_property_accessor: id set value "minecraft:lime_wall_banner"
execute if block ~ ~ ~ minecraft:lime_wall_banner[facing=north] run data modify storage block_property_accessor: properties.facing set value north
execute if block ~ ~ ~ minecraft:lime_wall_banner[facing=south] run data modify storage block_property_accessor: properties.facing set value south
execute if block ~ ~ ~ minecraft:lime_wall_banner[facing=west] run data modify storage block_property_accessor: properties.facing set value west
execute if block ~ ~ ~ minecraft:lime_wall_banner[facing=east] run data modify storage block_property_accessor: properties.facing set value east
execute if data storage block_property_accessor: {require_traits: true} run function block_property_accessor:0/0/0/1/1/1/1/0/0/lime_wall_banner_traits
