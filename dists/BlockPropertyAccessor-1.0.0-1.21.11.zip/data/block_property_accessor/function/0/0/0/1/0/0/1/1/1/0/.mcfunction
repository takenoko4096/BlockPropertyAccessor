execute if block ~ ~ ~ minecraft:copper_block run function block_property_accessor:0/0/0/1/0/0/1/1/1/0/copper_block
