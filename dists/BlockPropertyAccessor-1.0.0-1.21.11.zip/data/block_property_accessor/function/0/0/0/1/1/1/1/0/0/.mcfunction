execute if block ~ ~ ~ minecraft:lime_wall_banner run function block_property_accessor:0/0/0/1/1/1/1/0/0/lime_wall_banner
execute if block ~ ~ ~ minecraft:tuff_bricks run function block_property_accessor:0/0/0/1/1/1/1/0/0/tuff_bricks
